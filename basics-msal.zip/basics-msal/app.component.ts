app.component.ts
.
.
.
constructor(private consultasGenerales : ConsultasGenerales,
    private appService: AppService,
    public translate: TranslateService,
    public servicioComun: ServicioComun,
    private msalService: MsalService) { <--------
    translate.addLangs(['es','en', 'pt','br','tr']);
    translate.setDefaultLang('es');
    this.servicioComun.traductor = translate;


ngOnInit() {
    this.msalService.instance.handleRedirectPromise().then(
      res => {
        if (res != null && res.account != null) {
          this.msalService.instance.setActiveAccount(res.account);
          this.servicioComun.msalService = this.msalService;
          this.tengoMsalInstancia = true;
          do {
            this.servicioComun.user = this.getNuuma();
           // console.log ('...this.servicioComun.user=' + this.servicioComun.user);
          } while (this.tengoNuumaDeLaInstancia == null);
          this.manipulate();
        }
      }
    )
    this.login();

manipulate() {
    if (this.tengoMsalInstancia && this.tengoNuumaDeLaInstancia) {
      //this.servicioComun.user = this.getNuuma();
      console.log('NUUMA=' + this.servicioComun.user);
      this.usuarioHizoLogin = true;
      this.inicializaAplicacion();
    }
  }

  login() {
    // login via redirect
    this.msalService.loginRedirect();

    // login via pop up
    /*  this.msalService.loginPopup().subscribe( (response: AuthenticationResult) => {
     this.msalService.instance.setActiveAccount(response.account)
    }); */
  }

  logout() {
    this.msalService.logout();
  }

  getNuuma(): any{

    if (this.msalService.instance.getActiveAccount() === null) {
      this.nuumatmp = "No definido";
    } else {
      this.nuumatmp = this.msalService.instance.getActiveAccount().username;
      this.nuuma = this.nuumatmp.split("@", 1);

      console.log('...numaatmp=' + this.nuumatmp);
      console.log('...nuuma=' + this.nuuma);
      this.tengoNuumaDeLaInstancia = true;

    }

    return this.nuuma;
  }

  