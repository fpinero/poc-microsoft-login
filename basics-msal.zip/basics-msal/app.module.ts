app.module.ts
.
.
.
import { MsalModule, MsalService, MSAL_INSTANCE } from '@azure/msal-angular';
import { IPublicClientApplication, PublicClientApplication } from '@azure/msal-browser';

import { EnvService } from './env.service';


export function MSALInstanceFactory(env:EnvService): IPublicClientApplication {
  // alert('clientId=' + env.clientId);
  // alert('redirectUri=' + env.redirectUri);
  return new PublicClientApplication({
    auth: {
      clientId: env.clientId, 
      redirectUri: env.redirectUri, 
      postLogoutRedirectUri: 'https://www.myapp.com/logout',
      authority: 'https://login.microsoftonline.com/5cc6c66d-ffb2-469f-9385-xxxxxxxxx'
    }
  })
}

imports: [
    CoreModule,
    IconModule,
    SharedModule,
    NgMaterialMultilevelMenuModule,
    NgbModule,
    MsalModule
  ],
  providers: [DataSessionService, ServicioComun, ConsultasGenerales,FuncionesComunes,
    Guard, EnvServiceProvider,
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory,
      deps: [EnvService]
    },
    MsalService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HeaderInterceptor,
      multi: true // Add this line when using multiple interceptors.
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  entornoClientId: String;
  entornoRedirectUri: String;
  constructor(private env:EnvService) {

  this.entornoClientId = this.env.clientId;
  this.entornoRedirectUri = this.env.redirectUri;
  